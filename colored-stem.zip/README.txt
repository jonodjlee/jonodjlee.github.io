A Pen created at CodePen.io. You can find this one at https://codepen.io/jonathanlee/pen/MqbeWL.

 Watch the stem change color to reflect the post type as you scroll down the page. It's quite nice.